Hasnain Refrigeration — Final Website (multi-page) with galleries & lightbox
Pages included:
- index.html
- services.html
- service-ac-repair.html
- service-ac-maintenance.html
- service-electrician.html
- service-plumbing.html
- ac-sale.html
- contact.html

Assets in assets/img (placeholder images)
Forms use Formspree placeholder: REPLACE_WITH_FORMSPREE_ENDPOINT --> replace with your Formspree endpoint (e.g. /f/abcdxyz)
WhatsApp: +92 346 3838629

To deploy: upload the folder to Netlify (drag & drop) or host on any static host. Ensure index.html is at root.
